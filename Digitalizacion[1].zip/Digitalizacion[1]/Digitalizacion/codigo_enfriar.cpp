int lectura;
float voltaje, temp;
float kp = 0.0416;
float ki = 0.004;
float kd = 0.000;
float pro,der, integ;


float setpoint = 10.0; // Temperatura objetivo
float error_previo = 0;
float dutyCycle = 0.0; 

const int PWM= 9; // Salida del PWM
int PWM_read;
const int sensor_Temp = A0; // Pin del sensor de temperatura

unsigned long t0 = 0,t1;
const unsigned long t_muestreo = 100;//tiempo de sampling

// Variables para el temporizador de PWM
unsigned long periodo = 500; // Periodo de 100 ms para el PWM
unsigned long pwm_inicial,pwm_t1;
bool pwm_state = false; // Estado de la señal PWM
//////////////////////////

float alpha = 0.1; // Coeficiente del filtro (0.0 a 1.0, ajusta según el nivel de suavizado)
float temp_filtrada = 0; // Temperatura filtrada

void setup() 
{ pinMode(PWM, OUTPUT);
  Serial.begin(115200);
  pwm_inicial = millis(); //tiempo de inicio para mi PWM
}

void loop() 
{ t1 = millis();

  // Actualizaremos cada 100 ms
      if (t1 - t0 >= t_muestreo) 
      {           t0 = t1;
                  lectura = analogRead(sensor_Temp);
                  voltaje = 5.0 /1024 * lectura ;
                  temp = voltaje * 100 -50 ; 
                  
                  temp_filtrada = filtroExponencial(temp, temp_filtrada, alpha);
                  Serial.println(temp_filtrada);           
       }
       else
       {       
       }
      
      if(temp>setpoint)
      { dutyCycle = calculo_controlador(setpoint, temp_filtrada);
        genero_PWM(dutyCycle);
       }
      else if(temp<setpoint)
      {  //calentaremos
          digitalWrite(PWM, LOW);
      }
   
}


float calculo_controlador(float setpoint, float currentTemp) 
{ float error =  currentTemp - setpoint;
  pro = kp * error;
  integ += ki * error;
  der = kd * (error - error_previo);
  float valor_DC = pro + integ + der;
  valor_DC = constrain(valor_DC, 0, 1);
  error_previo = error;
  return valor_DC;
}

void genero_PWM(float DC) 
{     pwm_t1= millis();//tiempo actual para nuestro PWM
      unsigned long high = periodo * DC;
      unsigned long low = periodo - high;
      if ((pwm_t1 - pwm_inicial) < high) 
      {  digitalWrite(PWM, HIGH);  // Encender el PWM
         PWM_read=5;
      }   
      else if ((pwm_t1 - pwm_inicial) < periodo) 
      {     digitalWrite(PWM, LOW); // Apagar el PWM
            
            PWM_read=0;
      }
      //Serial.println(PWM_read);
      if (pwm_t1 - pwm_inicial >= periodo)
      {   pwm_inicial = pwm_t1;
      }
        
      
}

float filtroExponencial(float actual, float previo, float alpha) {
    return alpha * actual + (1 - alpha) * previo;
}