int lectura;
float voltaje, temp=8;
float kx;
float ky;
float kz;
float pro,der, integ;
float valor_DC;

float setpoint; // Temperatura objetivo
float error_previo = 0;
float error;
float dutyCycle = 0.0; 

const int PWM= 9; // Salida del PWM
int PWM_read;
const int sensor_Temp = A0; // Pin del sensor de temperatura

unsigned long t0 = 0,t1,ttt;
const unsigned long t_muestreo = 100;//tiempo de sampling
unsigned long high_p;
unsigned long low_p;

// Variables para el temporizador de PWM
unsigned long periodo = 500; // Periodo de 100 ms para el PWM
unsigned long pwm_inicial,pwm_t1;
bool pwm_state = false; // Estado de la señal PWM
//////////////////////////

float alpha = 0.1; // Coeficiente del filtro (0.0 a 1.0, ajusta según el nivel de suavizado)
float temp_filtrada = 0; // Temperatura filtrada

//////////////variables de subir Temperatura/////////////////
const int  S_estado_AC = 2;   
const int triac = 12;
int S_state = 0;
float S_T_CONTROL;// este sera el tiempo de control que debe de valer mas de 2200
float t_AC;
///////////////7variable para evitar oscilaciones//////////////
float temp_amb=23.0;// esto se puede implementar para que el sensor la detecte previamente.
int var;
void setup() 
{ pinMode(PWM, OUTPUT);
  pwm_inicial = millis(); //tiempo de inicio para mi PWM
  pinMode(S_estado_AC, INPUT);
  pinMode (triac, OUTPUT);
  Serial.begin(115200);

  //ttt=millis(); 
  setpoint = 30.0;
  
  
}
void loop() 
{   
      t1 = millis();
      if(t1-ttt>20000)
      {    setpoint = 40.0;
           if(t1-ttt>45000)
            { setpoint = 35.0;
              if(t1-ttt>65000)
               { setpoint = 10.0;
                  if(t1-ttt>115000)
                  {   setpoint = 15.0;
                  }
               }
            }
        
      }
      

    
      // Actualizaremos cada 100 ms
      if (t1 - t0 >= t_muestreo) 
      {           t0 = t1;
                  lectura = analogRead(sensor_Temp);
                  voltaje = 5.0 /1024 * lectura ;
                  temp = voltaje * 100 -50 ; 
                  
                  temp_filtrada = filtroExponencial(temp, temp_filtrada, alpha);
                  Serial.println(temp_filtrada);           
       }
       else
       {     
       }
                        
                 if((temp<setpoint)&&(setpoint>temp_amb))//CALENTAREMOS
                 {    var=1;
                      
                 }
                 else if((temp>setpoint)&&(setpoint>temp_amb))
                 {    if((temp-setpoint)<1)
                      {  var=2;
                      }
                      else if ((temp-setpoint)>1)
                      {var=3;
                      }
                 } 
                 else if((temp>setpoint)&&(setpoint<temp_amb))//ENFRIAR
                 {    var=3;
                 } 
                 else if((temp<setpoint)&&(setpoint<temp_amb))
                 {    if((temp-setpoint)>-1)
                      {  var=4;
                      }
                      else if((temp-setpoint)<-1)
                      { var=1;
                      }
                 } 
                  switch (var) 
                  {   case 1:
                         digitalWrite(PWM, LOW); // apagamos peltier
                         calentar_SOLO_AC();
                        break;
                      case 2:
                        digitalWrite(triac, LOW); // apagamos secadora
                       break;
                      case 3:
                        digitalWrite(triac, LOW); // apagamos secadora
                        enfriar_SOLO_PELTIER();
                       break;  
                      case 4:
                        digitalWrite(PWM, LOW); //apagamos peltier
                       break;
                      
                }
                 

}

float filtroExponencial(float actual, float previo, float alpha) {
    return alpha * actual + (1 - alpha) * previo;
}

float calculo_controladorUP(float setpoint, float currentTemp) 
{   kx = 125.0;
    ky = 0.1;
    kz = 0.000;
  error =  setpoint - currentTemp;
  pro = kx * error;
  integ += ky * error;
  der = kz * (error - error_previo);
  valor_DC = pro + integ + der;
  error_previo = error;
  return valor_DC;
}

//////////////////////////// FUNCIONES DE ENFRIAR/////////////////////////////////////
float calculo_controlador(float setpoint, float currentTemp) 
{  kx = 0.0416;
   ky = 0.004;
   kz = 0.000;
  
  error =  currentTemp - setpoint;
  pro = kx * error;
  integ += ky * error;
  der = kz * (error - error_previo);
  valor_DC = pro + integ + der;
  valor_DC = constrain(valor_DC, 0, 1);
  error_previo = error;
  return valor_DC;
}

void genero_PWM(float DC) 
{     pwm_t1= millis();//tiempo actual para nuestro PWM
      high_p = periodo * DC;
      low_p = periodo - high_p;
      if ((pwm_t1 - pwm_inicial) < high_p) 
      {  digitalWrite(PWM, HIGH);  // Encender el PWM
         PWM_read=5;
      }   
      else if ((pwm_t1 - pwm_inicial) < periodo) 
      {     digitalWrite(PWM, LOW); // Apagar el PWM
            
            PWM_read=0;
      }
      if (pwm_t1 - pwm_inicial >= periodo)
      {   pwm_inicial = pwm_t1;
      }
        
      
}
void calentar_SOLO_AC()
{         if(S_state == 0)
          {    if(digitalRead(S_estado_AC) == LOW)
                {  while(digitalRead(S_estado_AC)==LOW)
                   {//Serial.println("infinito");
                   }
                   S_state=5;
                 }
          }    
          else if (S_state == 5)
          { S_T_CONTROL = calculo_controladorUP(setpoint, temp_filtrada);
            t_AC = 6500-S_T_CONTROL;
            if(t_AC<2200)
            { t_AC=2200;
            }
            if(t_AC>6200)
            { t_AC=6200;
            }
            delayMicroseconds(t_AC);
            digitalWrite(triac, HIGH);
            delayMicroseconds(500);
            digitalWrite(triac, LOW);
            S_state = 0;
              
            
          }
  
}
void enfriar_SOLO_PELTIER()
{   dutyCycle = calculo_controlador(setpoint, temp_filtrada);
    genero_PWM(dutyCycle);

}
