﻿using Meadow;
using Meadow.Foundation;
using Meadow.Foundation.Sensors.Temperature;
using Meadow.Foundation.Graphics;
using Meadow.Foundation.Displays;
using Meadow.Devices;
using Meadow.Hardware;
using Meadow.Gateway.WiFi;
using Meadow.Units;
using System;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using NewCode.Web;
using NETDuinoWar;
using Meadow.Foundation.Relays;


namespace NewCode {
    public class MeadowApp : App<F7FeatherV2> {

        //Temperature Sensor
        private static AnalogTemperature sensor;

        //Relay
        public static Relay relay_dryer;
        public static Relay relay_peltier;

        public static IDigitalOutputPort transistor_dryer;
        public static IDigitalOutputPort transistor_peltier;

        //Display
        St7789 display;
        MicroGraphics graphics;

        // Time Controller Values
        public static int total_time = 0;
        public static int total_time_round = 0;
        public static int total_time_in_range = 0;
        public static int total_time_out_of_range = 0;
        public static int step = 0;
        public static int control = 0;

        public int count = 0;

        private static bool heating = false;
        private static bool cooling = false;

        double? lastValidTemperature = null;

        
        public override async Task Run() {
            try
            {
                if (count == 0) {
                Console.WriteLine("Initialization...");

                //Temperature Sensor Configuration
                sensor = new AnalogTemperature(analogPin: Device.Pins.A01, sensorType: AnalogTemperature.KnownSensorType.TMP36);
                sensor.TemperatureUpdated += AnalogTemperatureUpdated;
                sensor.StartUpdating(TimeSpan.FromSeconds(2));

                //relay_dryer = new Relay(port: Device.CreateDigitalOutputPort(Device.Pins.A03), type: Meadow.Peripherals.Relays.RelayType.NormallyOpen);
                //relay_peltier = new Relay(port: Device.CreateDigitalOutputPort(Device.Pins.A05), type: Meadow.Peripherals.Relays.RelayType.NormallyOpen);

                transistor_dryer = Device.CreateDigitalOutputPort(Device.Pins.D03);
                transistor_dryer.State = false;
                transistor_dryer.Dispose();


                transistor_peltier = Device.CreateDigitalOutputPort(Device.Pins.D05);
                transistor_peltier.State = false;
                transistor_peltier.Dispose();


                //Wifi Configuration
                var wifi = Device.NetworkAdapters.Primary<IWiFiNetworkAdapter>();
                wifi.NetworkConnected += WiFiAdapter_ConnectionCompleted;

                //WiFi Channel
                WifiNetwork wifiNetwork = ScanForAccessPoints(Secrets.WIFI_NAME);

                wifi.NetworkConnected += WiFiAdapter_WiFiConnected;
                await wifi.Connect(Secrets.WIFI_NAME, Secrets.WIFI_PASSWORD);

                string IPAddress = wifi.IpAddress.ToString();

                

                //Connnect to the WiFi network.
                Console.WriteLine($"IP Address: {IPAddress}");
                Data.IP = IPAddress;
                if (!string.IsNullOrWhiteSpace(IPAddress)) {
                    Data.IP = IPAddress;
                    WebServer webServer = new WebServer(wifi.IpAddress, Data.Port);
                    if (webServer != null) {
                        webServer.CommandReceived += WebServer_CommandReceived;
                        webServer.Start();
                    }
                }

                Console.WriteLine("Meadow Initialized!");


                new Thread(ReadTemp).Start();
                

                Console.WriteLine("Done.");


                count = count + 1;
            }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during initialization: {ex.Message}");
            }
        }

        //TW Combat Round
        public static void StartRound() {
            try
            {

                Stopwatch timer = Stopwatch.StartNew();
                timer.Start();
                total_time_in_range = 0;
                total_time_out_of_range = 0;
                step = 0;
                control = 0;

                Data.temps_actual = new string[0];
                Data.n_round = 0;

                // Change refresh time
                sensor.StopUpdating();
                sensor.StartUpdating(TimeSpan.FromMilliseconds(Data.refresh));


                //Initialization of time controller
                TimeController timeController = new TimeController();

                //Configuration of differents ranges
                TemperatureRange[] temperatureRanges = new TemperatureRange[Data.round_time.Length];

                //Range configurations
                bool success;
                string error_message = null;
                Data.is_working = true;


                //define ranges
                for (int i = 0; i < Data.temp_min.Length; i++)
                {
                    Console.WriteLine(Data.temp_max[i]);
                    temperatureRanges[i] = new TemperatureRange(double.Parse(Data.temp_min[i]), double.Parse(Data.temp_max[i]), int.Parse(Data.round_time[i]) * 1000);
                    total_time += int.Parse(Data.round_time[i]);
                }
                total_time_round = total_time;
                Data.time_total = $"{total_time}";

                // Initialization of timecontroller with the ranges
                timeController.DEBUG_MODE = false;
                success = timeController.Configure(temperatureRanges, total_time * 1000, Data.refresh, out error_message);
                Console.WriteLine(success);
                Console.WriteLine(error_message);

                //Initialization of timer
                new Thread(Timer).Start();

                Stopwatch regTempTimer = new Stopwatch();
                timeController.StartOperation();
                timeController.RegisterTemperature(double.Parse(Data.temp_act));
                regTempTimer.Start();

                Console.WriteLine("STARTING");

                //THE TW START WORKING
                while (Data.is_working)
                {

                    // Iniciar el contador
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();

                    // Algorithm logic
                    string actual_temp = Data.temp_act;
                    Array.Resize(ref Data.temps_actual, Data.temps_actual.Length + 1);
                    Data.temps_actual[Data.temps_actual.Length - 1] = actual_temp;
                    UpdateTemperatureControl(double.Parse(actual_temp));
                    //Temperature registration
                    timeController.RegisterTemperature(double.Parse(actual_temp));

                    // Detener el contador
                    stopwatch.Stop();
                    // Wait for refresh time
                    if (Data.refresh > (int)stopwatch.Elapsed.TotalMilliseconds)
                    {
                        Thread.Sleep(Data.refresh - (int)stopwatch.Elapsed.TotalMilliseconds);
                    }

                    regTempTimer.Restart();

                }
                Console.WriteLine("Round Finish");

                total_time_in_range += timeController.TimeInRangeInMilliseconds;
                total_time_out_of_range += timeController.TimeOutOfRangeInMilliseconds;
                Data.time_in_range_temp = (timeController.TimeInRangeInMilliseconds / 1000);

                Console.WriteLine("Tiempo dentro del rango " + ((timeController.TimeInRangeInMilliseconds / 1000)) + " s de " + total_time + " s");
                Console.WriteLine("Tiempo fuera del rango " + total_time_out_of_range / 1000 + " s de " + total_time + " s");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error when starting round: {ex.Message}");
            }
        }

        //Round Timer
        private static void Timer()
        {
            try
            {
                Data.is_working = true;
                double refresh = Convert.ToDouble(Convert.ToDouble(Data.refresh) / 1000);
                for (int i = 0; i < Data.round_time.Length; i++)
                {
                    Data.time_left = double.Parse(Data.round_time[i]);

                    while (Data.time_left > 0)
                    {
                        Data.time_left -= refresh;
                        Thread.Sleep(Data.refresh);
                    }

                    Data.n_round++;
                }
                Data.is_working = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in timer: {ex.Message}");
            }
        }



        // Temperature and Display Updated
        void AnalogTemperatureUpdated(object sender, IChangeResult<Meadow.Units.Temperature> e)
        {
            try
            {

                double currentTemperature = Math.Round((Double)e.New.Celsius, 1);

                // Validar si la nueva temperatura es una lectura válida
                if (!lastValidTemperature.HasValue)
                {
                    // Si es la primera lectura, se acepta incondicionalmente
                    lastValidTemperature = currentTemperature;
                }
                if (cooling)
                {
                    if (currentTemperature - lastValidTemperature.Value >= 6.0)
                    {
                        currentTemperature = lastValidTemperature.Value;

                    }
                    else
                    {
                        // Si la lectura es válida, actualizar la última temperatura válida
                        lastValidTemperature = currentTemperature;
                    }
                }

                else if (heating)
                {
                    if (lastValidTemperature.Value - currentTemperature >= 6.0)
                    {
                        currentTemperature = lastValidTemperature.Value;
                    }
                    else
                    {
                        // Si la lectura es válida, actualizar la última temperatura válida
                        lastValidTemperature = currentTemperature;
                    }
                }

                else if (Math.Abs(currentTemperature - lastValidTemperature.Value) >= 15.0)
                {
                    currentTemperature = lastValidTemperature.Value;
                }
                else
                {
                    // Si la lectura es válida, actualizar la última temperatura válida
                    lastValidTemperature = currentTemperature;
                }



                if (Data.ambient_count < 5 && Data.ambient_count >= 0)
                {
                    Data.ambient_temp_list[Data.ambient_count] = currentTemperature;
                    Data.ambient_count++;

                    if (Data.ambient_count == 5)
                    {
                        Data.ambient_temp = 0;
                        for (int i = 0; Data.ambient_count > 0; i++)
                        {
                            Data.ambient_temp += Data.ambient_temp_list[i];
                        }
                        Data.ambient_temp /= 5;
                    }
                }

                // Actualizar la temperatura actual en los datos
                Data.temp_act = currentTemperature.ToString();
                Console.WriteLine($"Temperature={Data.temp_act}");

                // Requisito de seguridad: 55ºC o más es una parada
                if (currentTemperature >= 55.0)
                {
                    Console.WriteLine("Temperature above 55.0, shutting down due to security risks");
                    System.Environment.Exit(-1);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating temperature: {ex.Message}");
            }
        }


        private static void UpdateTemperatureControl(double currentTemperature)
        {
            try
            {
                Console.WriteLine($"Current Temperature: {currentTemperature}°C");
                step = Data.n_round;

                double lowerThreshold = Convert.ToDouble(Data.temp_min[step]);  // First temperature range minimum
                double upperThreshold = Convert.ToDouble(Data.temp_max[step]);  // First temperature range maximum

                // Extract objective Temperature (can be modified)
                double objectiveTemperature = (upperThreshold + lowerThreshold) / 2;
                double temperatureDifference = currentTemperature;

                if (control == 0)
                {
                    // RANGO Infinito Lejos Arriba
                    if (temperatureDifference > (upperThreshold + 8.0))
                    {
                        Console.WriteLine("Rango infinito lejos Arriba");
                        control = 1;
                        
                        if (heating)
                        {
                            Console.WriteLine("Heating stopped");
                            turnOffDryer();
                            heating = false;
                        }
                        Thread t2 = new Thread(() => StartCooling(mode: 3));
                        t2.IsBackground = true;
                        t2.Start();
                        cooling = true;
                        heating = false;
                        
                    }
                    // RANGO Muy Lejos Arriba
                    else if (temperatureDifference > (upperThreshold + 3.0) && temperatureDifference <= (upperThreshold + 8.0))
                    {
                        Console.WriteLine("Rango muy lejos Arriba");
                        control = 1;
                        
                        if (heating)
                        {
                            Console.WriteLine("Heating stopped");
                            turnOffDryer();
                            heating = false;
                        }
                        Thread t2 = new Thread(() => StartCooling(mode: 3));
                        t2.IsBackground = true;
                        t2.Start();
                        cooling = true;
                        heating = false;
                        

                    }

                    // RANGO Lejos Arriba
                    else if (temperatureDifference <= (upperThreshold + 3.0) && temperatureDifference > upperThreshold && Data.ambient_temp > objectiveTemperature )
                    {
                        Console.WriteLine("Rango lejos Arriba");
                        control = 1;
                        
                        if (heating)
                        {
                            Console.WriteLine("Heating stopped");
                            turnOffDryer();
                            heating = false;
                        }
                        Thread t2 = new Thread(() => StartCooling(mode: 2));
                        t2.IsBackground = true;
                        t2.Start();
                        cooling = true;
                        heating = false;
                        
                    }

                    // RANGO Casi OK Arriba
                    else if (temperatureDifference <= upperThreshold && temperatureDifference > (objectiveTemperature + 0.5) && Data.ambient_temp > objectiveTemperature)
                    {
                        Console.WriteLine("Rango Casi OK Arriba");
                        control = 1;
                        
                        if (heating)
                        {
                            Console.WriteLine("Heating stopped");
                            turnOffDryer();
                            heating = false;
                        }
                        Thread t2 = new Thread(() => StartCooling(mode: 1));
                        t2.IsBackground = true;
                        t2.Start();
                        cooling = true;
                        heating = false;
                        
                    }

                    // RANGO OK
                    else if (temperatureDifference <= (objectiveTemperature + 0.5) && temperatureDifference > objectiveTemperature)
                    {
                        Console.WriteLine("Rango OK Arriba");

                    }

                    else if (temperatureDifference <= objectiveTemperature && temperatureDifference >= (objectiveTemperature - 0.5))
                    {
                        Console.WriteLine("Rango OK Abajo");
                        
                    }
                    // RANGO Casi OK Abajo
                    else if (temperatureDifference < (objectiveTemperature - 0.5) && temperatureDifference >= lowerThreshold && Data.ambient_temp < objectiveTemperature)
                    {
                        Console.WriteLine("Rango Casi OK Abajo");
                        control = 1;
                        
                        if (cooling)
                        {
                            Console.WriteLine("Cooling stopped");
                            turnOffPeltier();
                            cooling = false;
                        }
                        Thread t2 = new Thread(() => StartHeating(mode: 1));
                        t2.IsBackground = true;
                        t2.Start();
                        heating = true;
                        cooling = false;
                        
                    }

                    // RANGO Lejos Abajo
                    else if (temperatureDifference < lowerThreshold && temperatureDifference >= (lowerThreshold - 3.0) && Data.ambient_temp < objectiveTemperature)
                    {
                        Console.WriteLine("Rango Lejos Abajo");
                        control = 1;
                        
                        if (cooling)
                        {
                            Console.WriteLine("Cooling stopped");
                            turnOffPeltier();
                            cooling = false;
                        }
                        Thread t2 = new Thread(() => StartHeating(mode: 2));
                        t2.IsBackground = true;
                        t2.Start();
                        heating = true;
                        cooling = false;
                        
                    }

                    // RANGO Muy Lejos Abajo
                    else if (temperatureDifference < (lowerThreshold - 3.0) && temperatureDifference >= (lowerThreshold - 8.0))
                    {
                        Console.WriteLine("Rango Muy Lejos Abajo");
                        control = 1;
                        
                        if (cooling)
                        {
                            Console.WriteLine("Cooling stopped");
                            turnOffPeltier();
                            cooling = false;
                        }
                        Thread t2 = new Thread(() => StartHeating(mode: 3));
                        t2.IsBackground = true;
                        t2.Start();
                        heating = true;
                        cooling = false;
                        
                    }
                    // RANGO Infinito Lejos Abajo
                    else if (temperatureDifference < (lowerThreshold - 8.0)) {
                        Console.WriteLine("Rango Inifito Lejos Abajo");
                        control = 1;
                        
                        if (cooling)
                        {
                            Console.WriteLine("Cooling stopped");
                            turnOffPeltier();
                            cooling = false;
                        }
                        Thread t2 = new Thread(() => StartHeating(mode: 4));
                        t2.IsBackground = true;
                        t2.Start();
                        heating = true;
                        cooling = false;
                        
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating temperature control: {ex.Message}");
            }
        }

        private static void turnOnPeltier()
        {
            transistor_peltier.State = true;
        }
        private static void turnOffPeltier()
        {
            transistor_peltier.State = false;
        }
        private static void turnOnDryer()
        {
            transistor_dryer.State = true;
        }
        private static void turnOffDryer()
        {
            transistor_dryer.State = false;
        }


        // Methods to control the heating and cooling devices
        private static void StartHeating(int mode)
        {
            try
            {
                int time = 0;
                turnOffPeltier();
                cooling = false;

                if (mode == 1)
                {
                    turnOffDryer();
                    time = (int)(0.2 * Data.refresh);
                    Console.WriteLine("Heating started.");
                    turnOnDryer();
                    Thread.Sleep(time);
                    turnOffDryer();
                    Thread.Sleep((int)((Data.refresh - (2 * time)) / 2));
                    turnOnDryer();
                    Thread.Sleep(time);
                    turnOffDryer();
                    Thread.Sleep((int)((Data.refresh - (2 * time)) / 2));
                    Console.WriteLine("Heating finished.");
                    heating = false;

                }

                else if (mode == 2)
                {
                    turnOffDryer();
                    time = (int)(0.35 * Data.refresh);
                    Console.WriteLine("Heating started.");
                    turnOnDryer();
                    Thread.Sleep(time);
                    turnOffDryer();
                    Thread.Sleep((int)(0.25 * Data.refresh));
                    turnOnDryer();
                    Thread.Sleep((int)(0.2 * Data.refresh));
                    turnOffDryer();
                    Thread.Sleep((int)(0.2 * Data.refresh));
                    Console.WriteLine("Heating finished.");
                    heating = false;

                }

                else if (mode == 3)
                {
                    turnOffDryer();
                    time = (int)(0.45 * Data.refresh);
                    Console.WriteLine("Heating started.");
                    turnOnDryer();
                    Thread.Sleep(time);
                    turnOffDryer();
                    Thread.Sleep((int)((Data.refresh - (2 * time)) / 2));
                    turnOnDryer();
                    Thread.Sleep(time);
                    turnOffDryer();
                    Thread.Sleep((int)((Data.refresh - (2 * time)) / 2));
                    Console.WriteLine("Heating finished.");
                    heating = false;

                }

                else if (mode == 4)
                {
                    time = (int)(Data.refresh);
                    Console.WriteLine("Heating started.");
                    turnOnDryer();
                    Thread.Sleep(time);
                    heating = true;

                }
                control = 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error starting heating: {ex.Message}");
            }
        }

        private static void StartCooling(int mode)
        {
            try
            {
                int time = 0;
                turnOffDryer();
                heating = false;

                if (mode == 1)
                {
                    turnOffPeltier();
                    Console.WriteLine("Cooling started.");

                    turnOnPeltier();
                    Thread.Sleep((int)(Data.refresh * 0.4));
                    turnOffPeltier();
                    Thread.Sleep((int)(Data.refresh * 0.6));
                    Console.WriteLine("Cooling finished.");
                    cooling = false;

                }

                else if (mode == 2)
                {
                    turnOffPeltier();
                    Console.WriteLine("Cooling started.");
                    turnOnPeltier();
                    Thread.Sleep((int)(Data.refresh * 0.6));
                    turnOffPeltier();
                    Thread.Sleep((int)(Data.refresh * 0.4));
                    Console.WriteLine("Cooling finished.");
                    cooling = false;

                }
                else if (mode == 3)
                {
                    Console.WriteLine("Cooling started.");
                    turnOnPeltier();
                    Thread.Sleep(Data.refresh);
                    Console.WriteLine("Cooling finished.");
                    cooling = true;
                }
                control = 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error starting cooling: {ex.Message}");
            }
        }


        //Read Temperature Function
        async public void ReadTemp() {
            while (true)
            {
                var temperatura = await sensor.Read();
                Console.WriteLine($"Temperatura leido: {temperatura} celsius");
                Thread.Sleep(500);
            }
        }


        void WebServer_CommandReceived(object source, WebCommandEventArgs e) {
            if (source != null) {

            }
        }

        void WiFiAdapter_WiFiConnected(object sender, EventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    Console.WriteLine($"Connecting to WiFi Network {Secrets.WIFI_NAME}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error connecting to WiFi: {ex.Message}");
            }
        }

        void WiFiAdapter_ConnectionCompleted(object sender, EventArgs e) {
            Console.WriteLine("Connection request completed.");
        }

        protected WifiNetwork ScanForAccessPoints(string SSID)
        {
            try
            {
                WifiNetwork wifiNetwork = null;
                ObservableCollection<WifiNetwork> networks = new ObservableCollection<WifiNetwork>(Device.NetworkAdapters.Primary<IWiFiNetworkAdapter>().Scan()?.Result?.ToList()); //REVISAR SI ESTO ESTA BIEN
                wifiNetwork = networks?.FirstOrDefault(x => string.Compare(x.Ssid, SSID, true) == 0);
                return wifiNetwork;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error scanning for access points: {ex.Message}");
                return null;
            }
        }
    }
}