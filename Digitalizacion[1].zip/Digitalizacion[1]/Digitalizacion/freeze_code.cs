using System;
using System.Collections.Generic;
using System.Linq;

class MainClass {
    public static void Main (string[] args) {
        int reading;
        float voltage, temp, filteredTemp;
        const float kp = 0.0416;
        const float ki = 0.0004;
        const float kd = 0.0000;
        float proportionaError, integralError, derivativeError, previousError;
        float setPoint = 10.0;//goal temperature
        float workCycle = 0.1;//time between each reading
        const int PWM = 9;
        int PWMValue;
        const int tempSensor = 8;
        int currentTime, startTime = 0;
        int sampleTime = 100;//time between each reading
        


        //initialize PID controller
        System.Console.WriteLine("Filtered Temp");
        
    }

    public void generatePWM(float dcErrorValue) {
        //get current Time in milliseconds
        long currentTime = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
        int high = Data.refreshRate * dcErrorValue;
        int low = Data.refreshRate - high;

        if ((currentTime - startTime) < high) {
            //generate PWM signal
            digitalWrite(PWM, HIGH);
            } else if ((currentTime - startTime) < Data.refreshRate) {
                //turn off heater
                    digitalWrite(PWM, LOW);
                }
            
            startTime = currentTime;
        if (currentTime - startTime >= Data.refreshRate) {
            startTime = currentTime;
        }
    }

    public float controllerCalculator(float setPoint, float currentTemp) {
        //calculate error
        float error = currentTemp - setPoint;
        float proportionaError = kp * error;
        float integralError += ki * error;
        float derivativeError = kd * (error - previousError);
        float dcErrorValue = proportionaError + integralError + derivativeError;
        dcErrorValue = constrain(dcErrorValue, 0, 1);

        previousError = error;
        return dcErrorValue;
    }

    public float constrain(float value, float min, float max) {
        if (value < min) {
            return min;
        } else if (value > max) {
            return max;
        } else {
            return value;
        }
    }

    public float exponentialFilter(float actual, float previous, float alpha) {
        return alpha * actual + (1 - alpha) * previous;
    }
}
 