﻿namespace TemperatureWarriorCode {
    internal class Secrets {

        //WiFi NAME 
        public const string WIFI_NAME = "Galaxy A34";

        //PASSWORD FOR THE WiFi NAME
        public const string WIFI_PASSWORD = "sauhag476";
    }
}
