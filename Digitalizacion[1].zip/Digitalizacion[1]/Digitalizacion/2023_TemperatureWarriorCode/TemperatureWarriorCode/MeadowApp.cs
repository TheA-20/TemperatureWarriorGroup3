﻿using Meadow;
using Meadow.Foundation.Sensors.Temperature;
using Meadow.Devices;
using Meadow.Hardware;
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Meadow.Foundation.Relays;
using NETDuinoWar;
using TemperatureWarriorCode.Web;


namespace TemperatureWarriorCode
{
    public class MeadowApp : App<F7FeatherV2>
    {
        // Temperature Sensor
        private static AnalogTemperature sensor;

        //PID Parameters
        public static double Kp { get; set; } = 3.5; // 3;   // Proportional gain
        public static double Ki { get; set; } = 1.1; // 0.9;  // Integral gain
        public static double Kd { get; set; } = 0.09; // 0.09;  // Derivative gain
        public static double integralError { get; set; } = 0;
        public static double previousError { get; set; } = 0;
        public static double previousTemperature { get; set; } = 0;
        public static double dt { get; set; } = 0.001;
        public static double Epsilon { get; set; } = 0.05;

        //Relay
        public static Relay relay_dryer;
        public static Relay relay_peltier;

        public static IDigitalOutputPort transistor_dryer;
        public static IDigitalOutputPort transistor_peltier;

        // Time Controller Values
        public static double startTime = 0;
        public static int total_time = 0;
        //public static int total_time_round = 0;
        public static int total_time_in_range = 0;
        public static int total_time_out_of_range = 0;
        public static int step = 0;
        public static int control = 0;
        public int count = 0;
        private static bool heating = false;
        private static bool cooling = false;
        double? lastValidTemperature = null;
        public static Stopwatch pidTimer = new Stopwatch();

        public override async Task Run()
        {
            try
            {
                if (count == 0)
                {
                    Console.WriteLine("Initialization...");

                    // Temperature Sensor Configuration
                    sensor = new AnalogTemperature(analogPin: Device.Pins.A01, sensorType: AnalogTemperature.KnownSensorType.TMP36);
                    sensor.StartUpdating(TimeSpan.FromMilliseconds(500));
                    sensor.Updated += AnalogTemperatureUpdated;

                    //Relay and Transistors Configurations
                    relay_dryer = new Relay(port: Device.CreateDigitalOutputPort(Device.Pins.A03), type: Meadow.Peripherals.Relays.RelayType.NormallyOpen);
                    relay_peltier = new Relay(port: Device.CreateDigitalOutputPort(Device.Pins.A05), type: Meadow.Peripherals.Relays.RelayType.NormallyOpen);

                    transistor_dryer = Device.CreateDigitalOutputPort(Device.Pins.D03, false);
                    transistor_peltier = Device.CreateDigitalOutputPort(Device.Pins.D05, false);

                    Console.WriteLine("Meadow Initialized!");

                    var temperatura = await sensor.Read();
                    Data.temp_act = temperatura.ToString();

                    //Wifi Configuration, comentar para pruebas sin wifi
                    var wifi = Device.NetworkAdapters.Primary<IWiFiNetworkAdapter>();

                    wifi.NetworkConnected += (networkAdapter, networkConnectionEventArgs) =>
                    {
                        Console.WriteLine("Joined network");
                        Console.WriteLine($"IP Address: {networkAdapter.IpAddress}.");
                        Console.WriteLine($"Subnet mask: {networkAdapter.SubnetMask}");
                        Console.WriteLine($"Gateway: {networkAdapter.Gateway}");

                        //Connnect to the WiFi network.
                        Data.IP = networkAdapter.IpAddress.ToString();
                        if (!string.IsNullOrWhiteSpace(Data.IP))
                        {
                            WebServer webServer = new WebServer(networkAdapter.IpAddress, Data.Port);
                            if (webServer != null)
                            {
                                webServer.Start();
                            }
                        }
                    };

                    Console.Write("Connecting to Wifi");
                    await wifi.Connect(Secrets.WIFI_NAME, Secrets.WIFI_PASSWORD);

                    Console.WriteLine("Done.");

                    count++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during initialization: {ex.Message}");
            }
        }
        //TW Combat Round
        public static void StartRound()
        {
            Console.WriteLine(" Entre a inicio de ronda");
            try
            {
                Stopwatch timer = Stopwatch.StartNew();
                timer.Start();
                total_time = 0;
                total_time_in_range = 0;
                total_time_out_of_range = 0;
                step = 0;
                control = 0;

                Data.temps_actual = new string[0];
                Data.n_round = 0;

                // Change refresh time
                //sensor.StopUpdating();
                //sensor.StartUpdating(TimeSpan.FromMilliseconds(Data.refresh));

                //Initialization of time controller
                TimeController timeController = new TimeController();

                //Configuration of differents ranges
                TemperatureRange[] temperatureRanges = new TemperatureRange[Data.round_time.Length];

                //Range configurations
                bool success;
                string error_message = null;
                Data.is_working = true;

                //define ranges
                for (int i = 0; i < Data.temp_min.Length; i++)
                {
                    Console.WriteLine(Data.temp_max[i]);
                    temperatureRanges[i] = new TemperatureRange(double.Parse(Data.temp_min[i]), double.Parse(Data.temp_max[i]), int.Parse(Data.round_time[i]) * 1000);
                    total_time += int.Parse(Data.round_time[i]);
                }
                //total_time_round = total_time;
                Data.time_total = total_time;

                // Initialization of timecontroller with the ranges
                timeController.DEBUG_MODE = false;
                success = timeController.Configure(temperatureRanges, total_time * 1000, Data.refresh, out error_message);
                Console.WriteLine(success);
                Console.WriteLine(error_message);

                //Initialization of timer
                new Thread(Timer).Start();

                Stopwatch regTempTimer = new Stopwatch();
                timeController.StartOperation();
                timeController.RegisterTemperature(double.Parse(Data.temp_act));
                regTempTimer.Start();

                Console.WriteLine("STARTING");
                startTime = timer.ElapsedMilliseconds;
                pidTimer.Start();

                //THE TW START WORKING
                while (Data.is_working)
                {

                    // Iniciar el contador
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();

                    // Algorithm logic
                    string actual_temp = Data.temp_act;
                    Array.Resize(ref Data.temps_actual, Data.temps_actual.Length + 1);
                    Data.temps_actual[Data.temps_actual.Length - 1] = actual_temp;

                    UpdateTemperatureControl(double.Parse(actual_temp));

                    //Temperature registration
                    timeController.RegisterTemperature(double.Parse(actual_temp));

                    // Detener el contador
                    stopwatch.Stop();
                    // Wait for refresh time
                    if (Data.refresh > (int)stopwatch.Elapsed.TotalMilliseconds)
                    {
                        Console.WriteLine($"estamos aqui fuera liga {Data.refresh - (int)stopwatch.Elapsed.TotalMilliseconds}");
                        Thread.Sleep(Data.refresh - (int)stopwatch.Elapsed.TotalMilliseconds);
                    }

                    regTempTimer.Restart();

                }
                Console.WriteLine("Round Finish");

                total_time_in_range += timeController.TimeInRangeInMilliseconds;
                total_time_out_of_range += timeController.TimeOutOfRangeInMilliseconds;
                Data.time_in_range_temp = (timeController.TimeInRangeInMilliseconds / 1000);

                Console.WriteLine("Tiempo dentro del rango " + ((timeController.TimeInRangeInMilliseconds / 1000)) + " s de " + total_time + " s");
                Console.WriteLine("Tiempo fuera del rango " + total_time_out_of_range / 1000 + " s de " + total_time + " s");
                turnOffDryer();
                turnOffPeltier();
                return;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error when starting round: {ex.Message}");
            }
        }

        //Round Timer
        private static void Timer()
        {
            try
            {
                Data.is_working = true;
                double refresh = Convert.ToDouble(Convert.ToDouble(Data.refresh) / 1000); // refresh (ms) / 1000 = (s)
                Stopwatch timer = new Stopwatch();
                // this for loop last total_time
                for (int i = 0; i < Data.round_time.Length; i++)
                {
                    Data.time_left = double.Parse(Data.round_time[i]);  // (s)

                    while (Data.time_left > 0)
                    {

                        timer.Restart(); // Start the timer before the loop
                        Data.time_left -= refresh;

                        Console.WriteLine($"Data time left: {Data.time_left}");

                        // Calculate the time needed to sleep
                        long sleepTime = Data.refresh - timer.ElapsedMilliseconds;
                        if (sleepTime > 0)
                        {
                            Thread.Sleep((int)sleepTime);

                        }

                    }

                    Data.n_round++;
                }
                Data.is_working = false;

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in timer: {ex.Message}");
            }
        }


        // Temperature and Display Updated
        void AnalogTemperatureUpdated(object sender, IChangeResult<Meadow.Units.Temperature> e)
        {
            try
            {
                double currentTemperature = Math.Round((Double)e.New.Celsius, 1);

                // Validar si la nueva temperatura es una lectura válida
                if (!lastValidTemperature.HasValue)
                {
                    // Si es la primera lectura, se acepta incondicionalmente
                    lastValidTemperature = currentTemperature;
                }
                if (cooling)
                {
                    if (currentTemperature - lastValidTemperature.Value >= 6.0)
                    {
                        currentTemperature = lastValidTemperature.Value;

                    }
                    else
                    {
                        // Si la lectura es válida, actualizar la última temperatura válida
                        lastValidTemperature = currentTemperature;
                    }
                }

                else if (heating)
                {
                    if (lastValidTemperature.Value - currentTemperature >= 6.0)
                    {
                        currentTemperature = lastValidTemperature.Value;
                    }
                    else
                    {
                        // Si la lectura es válida, actualizar la última temperatura válida
                        lastValidTemperature = currentTemperature;
                    }
                }

                else if (Math.Abs(currentTemperature - lastValidTemperature.Value) >= 15.0)
                {
                    currentTemperature = lastValidTemperature.Value;
                }
                else
                {
                    // Si la lectura es válida, actualizar la última temperatura válida
                    lastValidTemperature = currentTemperature;
                }
                if (Data.ambient_count < Data.ambient_temp_list.Length) // Check if array isn't full
                {
                    Data.ambient_temp_list[Data.ambient_count] = currentTemperature;
                    Data.ambient_count++;

                    if (Data.ambient_count == Data.ambient_temp_list.Length) // Check if array is full
                    {
                        Data.ambient_temp = 0;
                        for (int i = 0; i < Data.ambient_temp_list.Length; i++) // Loop through the full array
                        {
                            Data.ambient_temp += Data.ambient_temp_list[i];
                        }
                        Data.ambient_temp /= Data.ambient_temp_list.Length; // Divide by the array length
                        Data.ambient_count = 0; // Reset the counter
                    }
                }
                // Actualizar la temperatura actual en los datos
                Data.temp_act = currentTemperature.ToString();
                Console.WriteLine($"Temperature={Data.temp_act}");

                // Requisito de seguridad: 30ºC o más es una parada
                if (currentTemperature >= 70.0)
                {
                    Console.WriteLine("Temperature above 30.0, shutting down due to security risks");
                    System.Environment.Exit(-1);
                }
                else if (currentTemperature <= 0.0)
                {
                    Console.WriteLine("Temperature below 12.0, shutting down due to security risks");
                    System.Environment.Exit(-1);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating temperature: {ex.Message}");
            }
        }

        private static void UpdateTemperatureControl(double currentTemperature)
        {
            try
            {
                Console.WriteLine($"Current Temperature: {currentTemperature}°C");

                step = Data.n_round;
                double lowerThreshold = Convert.ToDouble(Data.temp_min[step]);
                double upperThreshold = Convert.ToDouble(Data.temp_max[step]);
                double objectiveTemperature = (upperThreshold + lowerThreshold) / 2;
                Console.WriteLine($"Objective Temperature: {objectiveTemperature}°C");
                double output = controllerCalculator(objectiveTemperature, currentTemperature);

                if (output > Epsilon)
                {
                    Console.WriteLine($"Heating: {output}");
                    StartHeating();
                    cooling = false;
                    heating = true;
                }
                else if (output < -Epsilon)
                {
                    Console.WriteLine($"Cooling: {output}");
                    StartCooling();
                    cooling = true;
                    heating = false;
                }
                else
                {
                    Console.WriteLine("Temperature in range");
                    turnOffDryer();
                    turnOffPeltier();
                    cooling = false;
                    heating = false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating temperature control: {ex.Message}");
            }
        }

        public static void turnOnPeltier()
        {
            transistor_peltier.State = true;
        }
        public static void turnOffPeltier()
        {
            transistor_peltier.State = false;
        }
        public static void turnOnDryer()
        {
            transistor_dryer.State = true;
        }
        public static void turnOffDryer()
        {
            transistor_dryer.State = false;
        }

        public static double controllerCalculator(double setPoint, double currentTemperature)
        {
            double error = setPoint - currentTemperature;
            double proportionalError = Kp * error;
            integralError += Ki * error * (double)pidTimer.ElapsedMilliseconds / 1000.0; // Integral term
            double derivativeError = Kd * (currentTemperature - previousTemperature) / (double)pidTimer.ElapsedMilliseconds / 1000.0; // Derivative term

            double output = proportionalError + integralError - derivativeError;

            pidTimer.Restart();
            previousTemperature = currentTemperature;

            return output;
        }

        // Methods to control the heating and cooling devices
        public static void StartHeating()
        {
            try
            {
                turnOffPeltier();
                Console.WriteLine("Heating started.");
                turnOnDryer();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error starting heating: {ex.Message}");
            }
        }

        public static void StartCooling()
        {
            try
            {
                turnOffDryer();
                Console.WriteLine("Cooling started.");
                turnOnPeltier();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error starting cooling: {ex.Message}");
            }
        }

        //Read Temperature Function
        async public void ReadTemp()
        {
            while (true)
            {
                var temperatura = await sensor.Read();
                Data.temp_act = temperatura.ToString();
                //Console.WriteLine($"Temperatura leida: {temperatura} celsius");
                Thread.Sleep(500);
            }
        }
    }
}



