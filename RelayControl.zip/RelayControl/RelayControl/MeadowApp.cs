﻿using Meadow;
using Meadow.Devices;
using Meadow.Foundation.Leds;
using Meadow.Foundation.Sensors.Temperature;
using Meadow.Hardware;
using Meadow.Peripherals.Leds;
using System;
using System.Threading;
using System.Threading.Tasks; 

namespace RelayControl
{
    public class MeadowApp : App<F7FeatherV2>
    {
        private IDigitalOutputPort relayPort;
        private IDigitalOutputPort relayPort1;
        AnalogTemperature lm35;
       
        public override Task Initialize()
        {
            // Crear un puerto digital de salida en el pin D13 (ejemplo)
            relayPort = Device.CreateDigitalOutputPort(
                Device.Pins.D11,  // Cambia el pin según tu conexión
                initialState: false); // false = LOW (relé apagado)
            relayPort1 = Device.CreateDigitalOutputPort(
                Device.Pins.D13,
                initialState: false
                ); 
            
            lm35 = new AnalogTemperature(
                Device.Pins.A02,
                AnalogTemperature.KnownSensorType.LM35
            );

            // Evento de la librería (cada vez que StartUpdating detecta cambio)
            lm35.Updated += (s, result) =>
            {
                Resolver.Log.Info($"[Evento Lib] Temp LM35: {result.New.Celsius:N2} °C");
            };
            return base.Initialize();
        }

        public override Task Run()
        {
          
            while (true)
            {
                // Activar relé
                relayPort.State = true;   // HIGH
                relayPort1.State = false;   // LOW

                Thread.Sleep(5000);

                // Desactivar relé
                 relayPort.State = false;  // LOW
                 relayPort1.State= true;     //HIGH
                 Thread.Sleep(5000);

                // Inicia lecturas automáticas cada 1 segundo
                lm35.StartUpdating(TimeSpan.FromSeconds(1));
            }
        }
    }
}